﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
namespace Bücherladen
{
    class Exemplar
    {
        public int Nummer;
        public string Title;
        public Guid ProductId;
        public int Exemplare;
        public int AnzahlVerliehen;
        public string Art;
        public int Downloads;

        [JsonConstructor]
        public Exemplar(int nummer, Guid productId, string title, int exemplare, int downloads, string art, int anzahlVerliehen)
        {
            Nummer = nummer;
            ProductId = productId;
            Title = title;
            Exemplare = exemplare;
            Downloads = downloads;
            Art = art;
            AnzahlVerliehen = anzahlVerliehen;
        }

        public static List<Exemplar> MergeJson(List<Exemplar> jsonExemplareBucher, List<Exemplar> jsonExemplareMagazine)
        {
            var mergedExemplare = new List<Exemplar>();

            jsonExemplareBucher.AddRange(jsonExemplareMagazine.Select(exemplar => new Exemplar(exemplar.Nummer, exemplar.ProductId, exemplar.Title, exemplar.Exemplare, exemplar.Downloads, exemplar.Art, exemplar.AnzahlVerliehen)));

            mergedExemplare = jsonExemplareBucher;

            return mergedExemplare;
        }
    }
}
