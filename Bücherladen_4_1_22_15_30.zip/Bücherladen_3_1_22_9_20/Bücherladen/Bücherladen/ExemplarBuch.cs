﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Bücherladen
{
    public class ExemplarBuch
    {
        public int Nummer;
        public string Title;
        public Guid BuchId;
        public int Exemplare;
        public int AnzahlVerliehen;
        public string Art;
        public int Downloads;

        public ExemplarBuch(int nummer, Guid buchId, string title, int exemplare, int downloads)
        {
            Nummer = nummer;
            BuchId = buchId;
            Title = title;
            Exemplare = exemplare;
            Art = "BUCH";
            Downloads = downloads;
        }
    }
}
