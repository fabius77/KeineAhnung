﻿// ReSharper disable PossibleNullReferenceException

namespace Bücherladen
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var stopProgram = false;

            do
            {
                var mainMenuSelection = Menu.MainMenuSelection();

                Menu.SubMenu1(mainMenuSelection);

                stopProgram = Menu.EndProgramMenu();
            }
            while (!stopProgram);
        }
    }
}
