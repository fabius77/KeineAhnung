﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ConsoleTables;
using Newtonsoft.Json;
// ReSharper disable PossibleNullReferenceException

namespace Bücherladen
{
    public class Options
    {
        public static void List(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBooks = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_books.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var bucher = JsonConvert.DeserializeObject<List<Buch>>(Product.Load(pfadBucher));
            var magazine = JsonConvert.DeserializeObject<List<Magazin>>(Product.Load(pfadMagazine));
            var exemplareBooks = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBooks, pfadBucher));
            var exemplareMagazine =
                JsonConvert.DeserializeObject<List<ExemplarMagazin>>(Product.Load(pfadExemplareMagazine, pfadMagazine, true));
            var leihvorgange = new List<Leihvorgang>();

            if(File.Exists(pfadLeihvorgange))
                leihvorgange = JsonConvert.DeserializeObject<List<Leihvorgang>>(Product.Load(pfadLeihvorgange));

            switch (auswahl)
            {
                case 1:
                    var table = new ConsoleTable("Nummer", "Titel", "Author", "Seiten", "Land", "Sprache", "Erscheinungsjahr");
                    var i = 0;
                    foreach (var buch in bucher)
                    {
                        table.AddRow(++i, buch.Title, buch.Author, buch.Pages, buch.Country, buch.Language, buch.Year);
                    }
                    table.Write();
                    break;

                case 2:
                    Console.Write("Exemplar von Bücher(1) oder Magazine(2): ");
                    var selection = Convert.ToInt32(Console.ReadLine());

                    switch (selection)
                    {
                        case 1:
                            if (File.Exists(pfadExemplareBooks))
                            {
                                i = 0;
                                table = new ConsoleTable("Nummer", "Titel", "Exemplare", "verliehen");
                                foreach (var exemplar in exemplareBooks)
                                {
                                    table.AddRow(++i, exemplar.Title, exemplar.Exemplare, exemplar.AnzahlVerliehen);
                                }

                                table.Write();
                            }
                            else
                            {
                                Console.WriteLine("Keine Exemplare vorhanden.\n");
                            }

                            break;
                        case 2:
                            if (File.Exists(pfadExemplareMagazine))
                            {
                                i = 0;
                                table = new ConsoleTable("Nummer", "Titel", "Exemplare", "verliehen");
                                foreach (var exemplar in exemplareMagazine)
                                {
                                    table.AddRow(++i, exemplar.Title, exemplar.Exemplare, exemplar.AnzahlVerliehen);
                                }

                                table.Write();
                            }
                            else
                            {
                                Console.WriteLine("Keine Exemplare vorhanden.\n");
                            }
                            break;
                    }
                    break;

                case 3:
                    if (!File.Exists(pfadLeihvorgange))
                    {
                        Console.WriteLine("Aktuell wurden keine Bücher verliehen.\n");
                    }
                    else if (File.Exists(pfadLeihvorgange))
                    {
                        table = new ConsoleTable("Nummer", "Titel", "verliehen_am", "Leihdauer", "geliehen_von", "verfügbar ab");

                        i = 0;

                        foreach (var leihgabe in leihvorgange)
                        {
                            table.AddRow(++i, leihgabe.Title, leihgabe.VerliehenAm, leihgabe.Leihdauer, leihgabe.Kunde, leihgabe.VerfugbarAb);
                        }

                        table.Write();
                    }
                    break;
                case 4:
                    table = new ConsoleTable("Nummer", "Titel", "Gruppe", "Sachgruppe", "Verlag");
                    i = 0;
                    foreach (var magazin in magazine)
                    {
                        table.AddRow(++i, magazin.Title, magazin.Gruppe, magazin.Sachgruppe, magazin.Verlag);
                    }
                    table.Write();
                    break;
            }
        }

        public static void Add(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBooks = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_books.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var bucher = JsonConvert.DeserializeObject<List<Buch>>(Product.Load(pfadBucher));
            var magazine = JsonConvert.DeserializeObject<List<Magazin>>(Product.Load(pfadMagazine));
            var exemplareBooks = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBooks, pfadBucher));
            var exemplareMagazine =
                JsonConvert.DeserializeObject<List<ExemplarMagazin>>(Product.Load(pfadExemplareMagazine, pfadMagazine, true));
            var leihvorgange = new List<Leihvorgang>();

            if (File.Exists(pfadLeihvorgange))
                leihvorgange = JsonConvert.DeserializeObject<List<Leihvorgang>>(Product.Load(pfadLeihvorgange));

            switch (auswahl)
            {
                case 1:
                    Console.Write("Gib den Titel des neuen Buches ein: ");
                    var title = Console.ReadLine();
                    Console.Write("\nIn welchen Ländern ist das Buch verfügbar: ");
                    var country = Console.ReadLine();
                    Console.Write("\nIn welchen Sprachen gibt es das Buch: ");
                    var language = Console.ReadLine();
                    Console.Write("\nWie viele Seiten hat das Buch: ");
                    var pages = Convert.ToInt32(Console.ReadLine());
                    Console.Write("\nWer ist der Autor des Buches: ");
                    var author = Console.ReadLine();
                    Console.Write("\nWann ist das Buch erschienen: ");
                    var year = Convert.ToInt32(Console.ReadLine());
                    var buchNummer = bucher.Count + 1;
                    var buchId = Guid.NewGuid();

                    bucher.Add(new Buch("buch", buchNummer, title, author, pages, year, country, language, buchId));

                    exemplareBooks.Add(new ExemplarBuch(buchNummer, buchId, title, 2));

                    Product.Save(pfadBucher, JsonConvert.SerializeObject(bucher));

                    Product.Save(pfadExemplareBooks, JsonConvert.SerializeObject(exemplareBooks));

                    break;
                case 2:
                    Edit((int)ProductSelection.Exemplare);
                    break;
                case 3:
                    List((int)ProductSelection.Bucher);
                    var l = leihvorgange.Count;
                    var nichtGenugExemplare = false;

                    Console.Write("\nNummer des Buches: ");
                    var buchnummer = Convert.ToInt32(Console.ReadLine());

                    if (exemplareBooks[buchnummer - 1].AnzahlVerliehen >= exemplareBooks[buchnummer - 1].Exemplare)
                    {
                        nichtGenugExemplare = true;
                    }

                    while (nichtGenugExemplare)
                    {
                        Console.WriteLine("Leider sind alle Exemplare dieses Buches verliehen.");
                        Console.WriteLine("Ein anderes Buch stattdessen nehmen? (j/n)");
                        var anderesBuch = Console.ReadLine();
                        if (anderesBuch == "j")
                        {
                            Console.Write("\nNummer des Buches: ");
                            buchnummer = Convert.ToInt32(Console.ReadLine());
                            if (exemplareBooks[buchnummer - 1].AnzahlVerliehen < exemplareBooks[buchnummer - 1].Exemplare)
                            {
                                nichtGenugExemplare = false;
                            }
                        }
                        else
                        {
                            nichtGenugExemplare = false;
                        }
                    }

                    if (exemplareBooks[buchnummer - 1].AnzahlVerliehen < exemplareBooks[buchnummer - 1].Exemplare)
                    {
                        Console.Write("\nWer leiht das Buch aus: ");
                        var kunde = Console.ReadLine();

                        leihvorgange.Add(new Leihvorgang(Guid.NewGuid(), ++l, bucher[buchnummer - 1].Title, kunde, bucher[buchnummer-1].Id));

                        var neuAnzahlverliehen = exemplareBooks.Find(x => x.BuchId == leihvorgange[l - 1].BuchId)
                            .AnzahlVerliehen + 1;
                        exemplareBooks[buchnummer - 1].AnzahlVerliehen = neuAnzahlverliehen;

                        Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                        Product.Save(pfadExemplareBooks, JsonConvert.SerializeObject(exemplareBooks));
                    }
                    break;
                case 4:
                    Console.Write("Gib den Titel des neuen Magazins ein: ");
                    title = Console.ReadLine();
                    Console.Write("\nIn welchen Ländern ist das Magazin verfügbar: ");
                    var gruppe = Console.ReadLine();
                    Console.Write("\nIn welchen Sprachen gibt es das Magazin: ");
                    var sachgruppe = Console.ReadLine();
                    Console.Write("\nVon welchem Verlag ist das Magazin: ");
                    var verlag = Console.ReadLine();
                    var magazinNummer = magazine.Count + 1;
                    var magazinId = Guid.NewGuid();

                    magazine.Add(new Magazin("magazin", magazinNummer, title, gruppe, sachgruppe, verlag, magazinId));

                    exemplareMagazine.Add(new ExemplarMagazin(magazinNummer, magazinId, title, 2));

                    Product.Save(pfadMagazine, JsonConvert.SerializeObject(magazine));
                    Product.Save(pfadExemplareMagazine, JsonConvert.SerializeObject(exemplareMagazine));

                    break;
            }
        }

        public static void Del(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBooks = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_books.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var exemplareBooks = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBooks, pfadBucher));
            var exemplareMagazine =
                JsonConvert.DeserializeObject<List<ExemplarMagazin>>(Product.Load(pfadExemplareMagazine, pfadMagazine, true));
            var leihvorgange = new List<Leihvorgang>();

            switch (auswahl)
            {
                //case 1:
                    /*
                    List((int)ProductSelection.Bucher);

                    Console.Write("\nWelches Buch soll gelöscht werden?\nNummer des Buches: ");
                    var nummer = Convert.ToInt32(Console.ReadLine());

                    var entferntesBuch = bucher[nummer - 1].Title;

                    bucher.RemoveAt(nummer - 1);
                    exemplare.RemoveAt(nummer - 1);

                    var i = 0;
                    foreach (var exemplar in exemplare)
                    {
                        exemplar.Nummer = ++i;
                    }

                    Product.Save(pfadBucher, JsonConvert.SerializeObject(bucher));
                    Product.Save(pfadExemplare, JsonConvert.SerializeObject(exemplare));

                    Console.WriteLine("Eintrag {0} mit dem Titel \"{1}\" und die dazugehörigen Exemplare wurden entfernt.", nummer, entferntesBuch);
                    */
                    //break;
                case 2:
                    if (File.Exists(pfadExemplareBooks))
                    {
                        Options.List((int)ProductSelection.Exemplare);

                        Console.Write("\nVon welchem Buch möchten Sie Exemplare entfernen (Nummer): ");
                        var entfernteExemplare = Convert.ToInt32(Console.ReadLine());
                        Console.Write("\n{0} Exemplare sind momentan vermerkt. Wie viel sollen entfernt werden: ", exemplareBooks[entfernteExemplare].Exemplare);
                        var anzahlEntfernteExemplare = Convert.ToInt32(Console.ReadLine());

                        while (anzahlEntfernteExemplare < 0 || anzahlEntfernteExemplare > exemplareBooks.Count)
                        {
                            Console.WriteLine("So viele Exemplare können nicht entfernt werden.");
                            Console.Write("Wie viel sollen entfernt werden: ");
                            anzahlEntfernteExemplare = Convert.ToInt32(Console.ReadLine());
                        }

                        exemplareBooks[anzahlEntfernteExemplare].Exemplare = exemplareBooks[entfernteExemplare].Exemplare - anzahlEntfernteExemplare;
                        
                        Product.Save(pfadExemplareBooks, JsonConvert.SerializeObject(exemplareBooks));

                        Console.WriteLine("{0} Exemplar(e) wurde(n) erfolgreich entfernt.", anzahlEntfernteExemplare);
                    }
                    else
                    {
                        Console.WriteLine("\nKeine Exemplare vorhanden.");
                    }

                    break;
                case 3:
                    Options.List((int)ProductSelection.Leihvorgange);

                    Console.Write("Welcher Leihvorgang soll gelöscht werden (Nummer): ");
                    var zuLöschenderLeihvorgang = Convert.ToInt32(Console.ReadLine());

                    while (zuLöschenderLeihvorgang < 0 || zuLöschenderLeihvorgang > leihvorgange.Count)
                    {
                        Console.Write("Bitte gib eine vorhandene Nummer ein: ");
                        zuLöschenderLeihvorgang = Convert.ToInt32(Console.ReadLine());
                    }

                    var geloschterLeihvorgangKunde = leihvorgange.Find(x => x.Nummer == zuLöschenderLeihvorgang).Kunde;
                    var geloschterLeihvorgangTitle = leihvorgange.Find(x => x.Nummer == zuLöschenderLeihvorgang).Title;

                    var neuAnzahlverliehen = exemplareBooks.Find(x => x.BuchId == leihvorgange[zuLöschenderLeihvorgang - 1].BuchId).AnzahlVerliehen - 1;
                    exemplareBooks.Find(x => x.BuchId == leihvorgange[zuLöschenderLeihvorgang - 1].BuchId).AnzahlVerliehen = neuAnzahlverliehen;

                    leihvorgange.RemoveAll(p => p.Nummer == zuLöschenderLeihvorgang);

                    var l = 0;
                    foreach (var leihvorgang in leihvorgange)
                    {
                        l++;
                        leihvorgang.Nummer = l;
                    }

                    Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                    Product.Save(pfadExemplareBooks, JsonConvert.SerializeObject(exemplareBooks));

                    Console.WriteLine("\nLeihvorgang von \"{0}\" zum Buch {1} wurde entfernt.", geloschterLeihvorgangKunde, geloschterLeihvorgangTitle);

                    break;
            }
        }

        public static void Edit(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBooks = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_books.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var bucher = JsonConvert.DeserializeObject<List<Buch>>(pfadBucher);
            var magazine = JsonConvert.DeserializeObject<List<Magazin>>(Product.Load(pfadMagazine));
            var exemplareBooks = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBooks, pfadBucher));
            var exemplareMagazine =
                JsonConvert.DeserializeObject<List<ExemplarMagazin>>(Product.Load(pfadExemplareMagazine, pfadMagazine, true));
            var leihvorgange = new List<Leihvorgang>();

            switch (auswahl)
            {
                case 1:
                    List((int)ProductSelection.Bucher);
                    string mehrBearbeiten;
                    int editAuswahl;

                    Console.Write("Welches Buch möchten Sie bearbeiten (Nummer): ");
                    var buchBearbeiten = Convert.ToInt32(Console.ReadLine());

                    while (buchBearbeiten < 0 || buchBearbeiten > bucher.Count)
                    {
                        Console.WriteLine("Das Buch gibts es nicht.");
                        Console.Write("Buchnummer: ");
                        buchBearbeiten = Convert.ToInt32(Console.ReadLine());
                    }

                    //Process.Start(System.Environment.GetEnvironmentVariable("COMSPEC"), "/C " + "start " + "https://www.google.com/search?q=lesen+lernen#:~:text=aus%20dem%20Web-,Lesen%20lernen%3A%2012%20Tipps%20f%C3%BCr%20Eltern%20und%20Kinder%20(%2B%20%C3%9Cbungen),-Leselust%20wecken.");

                    var table = new ConsoleTable("Nummer", "Titel", "Author", "Seiten", "Land", "Sprache", "Erscheinungsjahr");

                    table.AddRow(bucher[buchBearbeiten - 1].Nummer, bucher[buchBearbeiten - 1].Title, bucher[buchBearbeiten - 1].Author, bucher[buchBearbeiten - 1].Pages, bucher[buchBearbeiten - 1].Country, bucher[buchBearbeiten - 1].Language, bucher[buchBearbeiten - 1].Year);
                    table.Write();


                    do
                    {
                        Console.WriteLine("\nWas möchten Sie bearbeiten?");
                        Console.WriteLine("Titel(1) \nAuthor(2) \nSeiten(3) \nLand(4) \nSprache(5) \nErscheinungsjahr(6)");
                        Console.Write("Nummer: ");
                        editAuswahl = Convert.ToInt32(Console.ReadLine());

                        switch (editAuswahl)
                        {
                            case 1:
                                Console.Write("Neuer/überarbeiteter Titel: ");
                                var title = Console.ReadLine();
                                bucher[buchBearbeiten].Title = title;
                                Console.WriteLine("Titel erfolgreich geändert in {0}", title);
                                break;
                            case 2:
                                Console.Write("Neuer/überarbeiteter Autor: ");
                                var author = Console.ReadLine();
                                bucher[buchBearbeiten].Author = author;
                                Console.WriteLine("Autor erfolgreich geändert in {0}", author);
                                break;
                            case 3:
                                Console.Write("Überarbeitete Seiten: ");
                                var pages = Convert.ToInt32(Console.ReadLine());
                                bucher[buchBearbeiten].Pages = pages;
                                Console.WriteLine("Seiten erfolgreich geändert in {0}", pages);
                                break;
                            case 4:
                                Console.Write("Neues/überarbeitetes Land: ");
                                var country = Console.ReadLine();
                                bucher[buchBearbeiten].Country = country;
                                Console.WriteLine("Land erfolgreich geändert in {0}", country);
                                break;
                            case 5:
                                Console.Write("Neue/überarbeitete Sprache: ");
                                var language = Console.ReadLine();
                                bucher[buchBearbeiten].Language = language;
                                Console.WriteLine("Sprache erfolgreich geändert in {0}", language);
                                break;
                            case 6:
                                Console.Write("Neues/überarbeitetes Erscheinungsjahr: ");
                                var year = Convert.ToInt32(Console.ReadLine());
                                bucher[buchBearbeiten].Year = year;
                                Console.WriteLine("Land erfolgreich geändert in {0}", year);
                                break;
                        }
                        Product.Save(pfadBucher, JsonConvert.SerializeObject(bucher));

                        Console.WriteLine("Mehr an diesem Buch bearbeiten? (j/n)");
                        mehrBearbeiten = Console.ReadLine();
                    } while (mehrBearbeiten == "j");
                    break;
                case 2:
                    List((int)ProductSelection.Exemplare);
                    Console.WriteLine("Welche Exemplare möchten Sie bearbeiten (Nummer): ");
                    var exemplarBearbeiten = Convert.ToInt32(Console.ReadLine());

                    while (exemplarBearbeiten < 0 || exemplarBearbeiten > exemplareBooks.Count)
                    {
                        Console.WriteLine("Dieses Buch gibt es nicht.");
                        Console.Write("Nummer: ");
                        exemplarBearbeiten = Convert.ToInt32(Console.ReadLine());
                    }

                    table = new ConsoleTable("Nummer", "Titel", "Exemplare", "verliehen");
                    table.AddRow(exemplareBooks[exemplarBearbeiten - 1].Nummer, exemplareBooks[exemplarBearbeiten - 1].Title, exemplareBooks[exemplarBearbeiten - 1].Exemplare, exemplareBooks[exemplarBearbeiten - 1].AnzahlVerliehen);
                    table.Write();

                    Console.WriteLine("\nWas möchten Sie editieren?");
                    Console.WriteLine("\nExemplare(1)");
                    Console.Write("Nummer: ");
                    editAuswahl = Convert.ToInt32(Console.ReadLine());

                    switch (editAuswahl)
                    {
                        case 1:
                            Console.Write("Neuer Anzahl an Exemplaren: ");
                            var neueAnzahlExemplare = Convert.ToInt32(Console.ReadLine());
                            exemplareBooks[exemplarBearbeiten].Exemplare = neueAnzahlExemplare;
                            Console.WriteLine("Exemplare erfolgreich geändert in {0}", neueAnzahlExemplare);
                            break;
                    }
                    Product.Save(pfadExemplareBooks, JsonConvert.SerializeObject(exemplareBooks));
                    break;
                case 3:
                    List((int)ProductSelection.Leihvorgange);
                    Console.Write("Welchen Leihvorgang möchten Sie bearbeiten (Nummer): ");
                    var leihvorgangBearbeiten = Convert.ToInt32(Console.ReadLine());

                    table = new ConsoleTable("Nummer", "Titel", "verliehen am", "Leihdauer", "geliehen von", "verfügbar ab");
                    table.AddRow(leihvorgange[leihvorgangBearbeiten - 1].Nummer,
                        leihvorgange[leihvorgangBearbeiten - 1].Title,
                        leihvorgange[leihvorgangBearbeiten - 1].VerliehenAm,
                        leihvorgange[leihvorgangBearbeiten - 1].Leihdauer,
                        leihvorgange[leihvorgangBearbeiten - 1].Kunde,
                        leihvorgange[leihvorgangBearbeiten - 1].VerfugbarAb);
                    table.Write();

                    Console.WriteLine("Was möchten Sie bearbeiten?");
                    Console.WriteLine("\ngeliehen von(1) \nLeihdauer(2)");
                    Console.Write("Nummer: ");
                    editAuswahl = Convert.ToInt32(Console.ReadLine());

                    switch (editAuswahl)
                    {
                        case 1:
                            Console.Write("Neuer Kunde: ");
                            var kunde = Console.ReadLine();
                            leihvorgange[leihvorgangBearbeiten-1].Kunde = kunde;
                            Console.WriteLine("Kunde/verliehen an erfolgreich geändert in {0}", kunde);
                            break;
                        case 2:
                            Console.Write("Neue Leihdauer: ");
                            var leihdauer = Convert.ToInt32(Console.ReadLine());
                            leihvorgange[leihvorgangBearbeiten - 1].Leihdauer = leihdauer;

                            var verfugbarAb = Convert.ToDateTime(leihvorgange[leihvorgangBearbeiten - 1].VerliehenAm)
                                .AddDays(leihdauer).ToString("dd/MM/yyyy");
                            leihvorgange[leihvorgangBearbeiten - 1].VerfugbarAb = verfugbarAb;
                            break;
                    }
                    Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                    break;
                case 4:
                    List((int)ProductSelection.Magazine);

                    Console.Write("Welches Magazin möchten Sie bearbeiten (Nummer): ");
                    var magazinBearbeiten = Convert.ToInt32(Console.ReadLine());

                    while (magazinBearbeiten < 0 || magazinBearbeiten> magazine.Count)
                    {
                        Console.WriteLine("Das Buch gibts es nicht.");
                        Console.Write("Buchnummer: ");
                        magazinBearbeiten = Convert.ToInt32(Console.ReadLine());
                    }

                    table = new ConsoleTable("Nummer", "Titel", "Gruppe", "Sachgruppe", "Verlag");

                    table.AddRow(magazine[magazinBearbeiten - 1].Nummer, magazine[magazinBearbeiten - 1].Title, magazine[magazinBearbeiten - 1].Gruppe, magazine[magazinBearbeiten - 1].Sachgruppe, magazine[magazinBearbeiten - 1].Verlag);
                    table.Write();

                    do
                    {
                        Console.WriteLine("\nWas möchten Sie bearbeiten?");
                        Console.WriteLine("Titel(1) \nGurppe(2) \nSachgruppe(3) \nVerlag(4)");
                        Console.Write("Nummer: ");
                        editAuswahl = Convert.ToInt32(Console.ReadLine());

                        switch (editAuswahl)
                        {
                            case 1:
                                Console.Write("Neuer/überarbeiteter Titel: ");
                                var title = Console.ReadLine();
                                bucher[magazinBearbeiten].Title = title;
                                Console.WriteLine("Titel erfolgreich geändert in {0}", title);
                                break;
                            case 2:
                                Console.Write("Neuee/überarbeitete Gruppe: ");
                                var author = Console.ReadLine();
                                bucher[magazinBearbeiten].Author = author;
                                Console.WriteLine("Gruppe erfolgreich geändert in {0}", author);
                                break;
                            case 3:
                                Console.Write("Überarbeitete Sachgruppe: ");
                                var pages = Convert.ToInt32(Console.ReadLine());
                                bucher[magazinBearbeiten].Pages = pages;
                                Console.WriteLine("Sachgruppe erfolgreich geändert in {0}", pages);
                                break;
                            case 4:
                                Console.Write("Neuer/Überarbeiteter Verlag: ");
                                var country = Console.ReadLine();
                                bucher[magazinBearbeiten].Country = country;
                                Console.WriteLine("Verlag erfolgreich geändert in {0}", country);
                                break;
                        }
                        Product.Save(pfadMagazine, JsonConvert.SerializeObject(magazine));

                        Console.WriteLine("Mehr an diesem Magazin bearbeiten? (j/n)");
                        mehrBearbeiten = Console.ReadLine();
                    } while (mehrBearbeiten == "j");
                    break;
            }
        }
    }
}
