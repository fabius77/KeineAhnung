﻿namespace Bücherladen
{
    public enum ProductSelection
    {
        Bucher = 1,
        Exemplare = 2,
        Leihvorgange = 3,
        Magazine = 4
    }
}
