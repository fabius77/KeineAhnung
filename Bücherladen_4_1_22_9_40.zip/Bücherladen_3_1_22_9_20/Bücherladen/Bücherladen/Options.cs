﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ConsoleTables;
using Newtonsoft.Json;
// ReSharper disable PossibleNullReferenceException

namespace Bücherladen
{
    public class Options
    {
        public static void List(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBucher = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_magazine.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var bucher = JsonConvert.DeserializeObject<List<Buch>>(Product.Load(pfadBucher));
            var magazine = JsonConvert.DeserializeObject<List<Magazin>>(Product.Load(pfadMagazine));
            var exemplareBucher = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBucher, pfadBucher));
            var exemplareMagazine = JsonConvert.DeserializeObject<List<ExemplarMagazin>>(Product.Load(pfadExemplareMagazine, pfadMagazine, true));
            var leihvorgange = new List<Leihvorgang>();
            bool fehler;

            Product.CorrectWrongId(bucher, pfadBucher);
            Product.CorrectWrongId(magazine, pfadMagazine);

            if(File.Exists(pfadLeihvorgange))
                leihvorgange = JsonConvert.DeserializeObject<List<Leihvorgang>>(Product.Load(pfadLeihvorgange));

            switch (auswahl)
            {
                case 1:
                    var table = new ConsoleTable("Nummer", "Titel", "Author", "Seiten", "Land", "Sprache", "Erscheinungsjahr");
                    var i = 0;
                    foreach (var buch in bucher)
                    {
                        table.AddRow(++i, buch.Title, buch.Author, buch.Pages, buch.Country, buch.Language, buch.Year);
                    }
                    table.Write();

                    break;

                case 2:
                    if (File.Exists(pfadExemplareBucher))
                    {
                        Console.Write("Bücher(1) oder Magazine(2): ");
                        var exemplareAnsichtAuswahl = Convert.ToInt32(Console.ReadLine());

                        do
                        {
                            try
                            {
                                exemplareAnsichtAuswahl = Convert.ToInt32(Console.ReadLine());
                                fehler = false;
                            }
                            catch
                            {
                                Console.WriteLine("Bitte geben Sie eine Zahl von 1 bis 2 ein.");
                                fehler = true;
                            }
                        }
                        while (fehler);

                        switch (exemplareAnsichtAuswahl)
                        {
                            case 1:
                                i = 0;
                                table = new ConsoleTable("Nummer", "Art", "Titel", "Exemplare", "verliehen", "Downloads");
                                foreach (var exemplar in exemplareBucher)
                                {
                                    table.AddRow(++i, exemplar.Art, exemplar.Title, exemplar.Exemplare, exemplar.AnzahlVerliehen, exemplar.Downloads);
                                }

                                table.Write();

                                break;

                            case 2:
                                i = 0;
                                table = new ConsoleTable("Nummer", "Art", "Titel", "Exemplare", "verliehen", "Downloads");
                                foreach (var exemplar in exemplareMagazine)
                                {
                                    table.AddRow(++i, exemplar.Art, exemplar.Title, exemplar.Exemplare, exemplar.AnzahlVerliehen, exemplar.Downloads);
                                }

                                table.Write();

                                break;

                        }
                    }
                    else
                    {
                        Console.WriteLine("Keine Exemplare vorhanden.\n");
                    }

                    break;

                case 3:
                    if (!File.Exists(pfadLeihvorgange))
                    {
                        Console.WriteLine("Aktuell wurden keine Bücher verliehen.\n");
                    }
                    else if (File.Exists(pfadLeihvorgange))
                    {
                        table = new ConsoleTable("Nummer", "Art", "Titel", "verliehen_am", "Leihdauer", "geliehen_von", "verfügbar ab");

                        i = 0;

                        foreach (var leihgabe in leihvorgange)
                        {
                            table.AddRow(++i, leihgabe.Art, leihgabe.Title, leihgabe.VerliehenAm, leihgabe.Leihdauer, leihgabe.Kunde, leihgabe.VerfugbarAb);
                        }

                        table.Write();
                    }

                    break;

                case 4:
                    table = new ConsoleTable("Nummer", "Art", "Titel", "Gruppe", "Sachgruppe", "Verlag");
                    i = 0;

                    foreach (var magazin in magazine)
                    {
                        table.AddRow(++i, magazin.Art, magazin.Title, magazin.Gruppe, magazin.Sachgruppe, magazin.Verlag);
                    }
                    table.Write();

                    break;

                case 5:
                    table = new ConsoleTable("Nummer", "Art", "Titel", "Downloads");
                    i = 0;

                    foreach(var magazin in exemplareMagazine)
                    {
                        if(magazin.Downloads != 0)
                        {
                            table.AddRow(++i, magazin.Art, magazin.Title, magazin.Downloads);
                        }
                    }

                    foreach(var buch in exemplareBucher)
                    {
                        if(buch.Downloads != 0)
                        {
                            table.AddRow(++i, buch.Art, buch.Title, buch.Downloads);
                        }
                    }

                    table.Write();

                    break;
            }
        }

        public static void Add(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBucher = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_magazine.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var bucher = JsonConvert.DeserializeObject<List<Buch>>(Product.Load(pfadBucher));
            var magazine = JsonConvert.DeserializeObject<List<Magazin>>(Product.Load(pfadMagazine));
            var exemplareBucher = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBucher, pfadBucher));
            var exemplareMagazine = JsonConvert.DeserializeObject<List<ExemplarMagazin>>(Product.Load(pfadExemplareMagazine, pfadMagazine));
            var leihvorgange = new List<Leihvorgang>();

            if (File.Exists(pfadLeihvorgange))
                leihvorgange = JsonConvert.DeserializeObject<List<Leihvorgang>>(Product.Load(pfadLeihvorgange));

            switch (auswahl)
            {
                case 1:
                    Console.Write("Gib den Titel des neuen Buches ein: ");
                    var title = Console.ReadLine();
                    Console.Write("\nIn welchen Ländern ist das Buch verfügbar: ");
                    var country = Console.ReadLine();
                    Console.Write("\nIn welchen Sprachen gibt es das Buch: ");
                    var language = Console.ReadLine();
                    Console.Write("\nWie viele Seiten hat das Buch: ");
                    var pages = Convert.ToInt32(Console.ReadLine());
                    Console.Write("\nWer ist der Autor des Buches: ");
                    var author = Console.ReadLine();
                    Console.Write("\nWann ist das Buch erschienen: ");
                    var year = Convert.ToInt32(Console.ReadLine());
                    var buchNummer = bucher.Count + 1;
                    var buchId = Guid.NewGuid();

                    bucher.Add(new Buch("BUCH", buchNummer, title, author, pages, year, country, language, buchId));

                    exemplareBucher.Add(new ExemplarBuch(buchNummer, buchId, title, 2, 0));

                    Product.Save(pfadBucher, JsonConvert.SerializeObject(bucher));

                    Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplareBucher));

                    break;
                case 2:
                    Edit((int)ProductSelection.Exemplare);
                    break;
                case 3:
                    Console.Write("Buch(1) oder Magazin(2): ");
                    var leihvorgangAnlegenAuswahl = Convert.ToInt32(Console.ReadLine());
                    switch (leihvorgangAnlegenAuswahl)
                    {
                        case 1:
                            List((int)ProductSelection.Bucher);
                            var l = leihvorgange.Count;
                            var nichtGenugExemplare = false;

                            Console.Write("\nNummer des Buches: ");
                            var buchnummer = Convert.ToInt32(Console.ReadLine());

                            if (exemplareBucher[buchnummer - 1].AnzahlVerliehen >= exemplareBucher[buchnummer - 1].Exemplare)
                            {
                                nichtGenugExemplare = true;
                            }

                            while (nichtGenugExemplare)
                            {
                                Console.WriteLine("Leider sind alle Exemplare dieses Buches verliehen.");
                                Console.WriteLine("Ein anderes Buch stattdessen nehmen? (j/n)");
                                var anderesBuch = Console.ReadLine();
                                if (anderesBuch == "j")
                                {
                                    Console.Write("\nNummer des Buches: ");
                                    buchnummer = Convert.ToInt32(Console.ReadLine());
                                    if (exemplareBucher[buchnummer - 1].AnzahlVerliehen < exemplareBucher[buchnummer - 1].Exemplare)
                                    {
                                        nichtGenugExemplare = false;
                                    }
                                }
                                else
                                {
                                    nichtGenugExemplare = false;
                                }
                            }

                            if (exemplareBucher[buchnummer - 1].AnzahlVerliehen < exemplareBucher[buchnummer - 1].Exemplare)
                            {
                                Console.Write("\nWer leiht das Buch aus: ");
                                var kunde = Console.ReadLine();

                                leihvorgange.Add(new Leihvorgang(Guid.NewGuid(), ++l, bucher[buchnummer - 1].Title, kunde, bucher[buchnummer - 1].Id, "BUCH"));

                                var neuAnzahlverliehen = exemplareBucher.Find(x => x.Title == leihvorgange[l - 1].Title)
                                    .AnzahlVerliehen + 1;
                                exemplareBucher[buchnummer - 1].AnzahlVerliehen = neuAnzahlverliehen;

                                Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                                Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplareBucher));
                            }
                            break;
                        case 2:
                            List((int)ProductSelection.Magazine);
                            l = leihvorgange.Count;
                            nichtGenugExemplare = false;

                            Console.Write("\nNummer des Magazins: ");
                            var magazinnummer = Convert.ToInt32(Console.ReadLine());

                            if (exemplareMagazine[magazinnummer - 1].AnzahlVerliehen >= exemplareMagazine[magazinnummer - 1].Exemplare)
                            {
                                nichtGenugExemplare = true;
                            }

                            while (nichtGenugExemplare)
                            {
                                Console.WriteLine("Leider sind alle Exemplare dieses Buches verliehen.");
                                Console.WriteLine("Ein anderes Buch stattdessen nehmen? (j/n)");
                                var anderesBuch = Console.ReadLine();
                                if (anderesBuch == "j")
                                {
                                    Console.Write("\nNummer des Magazins: ");
                                    buchnummer = Convert.ToInt32(Console.ReadLine());
                                    if (exemplareMagazine[buchnummer - 1].AnzahlVerliehen < exemplareMagazine[buchnummer - 1].Exemplare)
                                    {
                                        nichtGenugExemplare = false;
                                    }
                                }
                                else
                                {
                                    nichtGenugExemplare = false;
                                }
                            }

                            if (exemplareMagazine[magazinnummer - 1].AnzahlVerliehen < exemplareMagazine[magazinnummer - 1].Exemplare)
                            {
                                Console.Write("\nWer leiht das Magazin aus: ");
                                var kunde = Console.ReadLine();

                                leihvorgange.Add(new Leihvorgang(Guid.NewGuid(), ++l, magazine[magazinnummer - 1].Title, kunde, magazine[magazinnummer - 1].Id, "MAGAZIN", true));

                                var neuAnzahlverliehen = exemplareMagazine.Find(x => x.Title == leihvorgange[l - 1].Title)
                                    .AnzahlVerliehen + 1;
                                exemplareMagazine[magazinnummer - 1].AnzahlVerliehen = neuAnzahlverliehen;

                                Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                                Product.Save(pfadExemplareMagazine, JsonConvert.SerializeObject(exemplareMagazine));
                            }
                            break;
                    }
                    
                    break;
                case 4:
                    Console.Write("Gib den Titel des neuen Magazins ein: ");
                    title = Console.ReadLine();
                    Console.Write("\nIn welchen Ländern ist das Magazin verfügbar: ");
                    var gruppe = Console.ReadLine();
                    Console.Write("\nIn welchen Sprachen gibt es das Magazin: ");
                    var sachgruppe = Console.ReadLine();
                    Console.Write("\nVon welchem Verlag ist das Magazin: ");
                    var verlag = Console.ReadLine();
                    var magazinNummer = magazine.Count + 1;
                    var magazinId = Guid.NewGuid();

                    magazine.Add(new Magazin("magazin", magazinNummer, title, gruppe, sachgruppe, verlag, magazinId));

                    exemplareMagazine.Add(new ExemplarMagazin(magazinNummer, magazinId, title, 2, 0));

                    Product.Save(pfadMagazine, JsonConvert.SerializeObject(magazine));
                    Product.Save(pfadExemplareMagazine, JsonConvert.SerializeObject(exemplareMagazine));

                    break;

                case 5:
                    Console.WriteLine("Wovon soll ein Download-Link erstellt werden?");
                    Console.WriteLine("e-Book(1) oder e-Paper(2)");
                    var createDownloadLinkSelection = Convert.ToInt32(Console.ReadLine());

                    switch (createDownloadLinkSelection)
                    {
                        case 1:
                            List((int)ProductSelection.Bucher);

                            Console.Write("\nVon welchem e-Book soll ein Download-Link erstellt werden?: ");

                            createDownloadLinkSelection = Convert.ToInt32(Console.ReadLine());

                            exemplareBucher[createDownloadLinkSelection - 1].Downloads += 1;

                            Console.WriteLine("\nDer Download-Link für das e-Book \"{0}\" wurde erstellt.\n", exemplareBucher[createDownloadLinkSelection-1].Title);

                            Console.WriteLine(@"https://www.buchladen.de/e-book/download/" + Guid.NewGuid().ToString().Replace("-", "") + "\n");

                            Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplareBucher));

                            break;
                        case 2:
                            List((int)ProductSelection.Magazine);

                            Console.Write("\nVon welchem e-Paper soll ein Download-Link erstellt werden?: ");

                            createDownloadLinkSelection = Convert.ToInt32(Console.ReadLine());

                            exemplareMagazine[createDownloadLinkSelection - 1].Downloads += 1;

                            Console.WriteLine("\nDer Download-Link für das e-Paper \"{0}\" wurde erstellt.\n", exemplareMagazine[createDownloadLinkSelection - 1].Title);

                            Console.WriteLine(@"https://www.buchladen.de/e-book/download/" + Guid.NewGuid().ToString().Replace("-", "") + "\n");

                            Product.Save(pfadExemplareMagazine, JsonConvert.SerializeObject(exemplareMagazine));

                            break;
                    }
                    break;
            }
        }

        public static void Del(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBucher = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_books.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var exemplareBucher = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBucher, pfadBucher));
            var leihvorgange = new List<Leihvorgang>();

            switch (auswahl)
            {
                //case 1:
                    /*
                    List((int)ProductSelection.Bucher);

                    Console.Write("\nWelches Buch soll gelöscht werden?\nNummer des Buches: ");
                    var nummer = Convert.ToInt32(Console.ReadLine());

                    var entferntesBuch = bucher[nummer - 1].Title;

                    bucher.RemoveAt(nummer - 1);
                    exemplare.RemoveAt(nummer - 1);

                    var i = 0;
                    foreach (var exemplar in exemplare)
                    {
                        exemplar.Nummer = ++i;
                    }

                    Product.Save(pfadBucher, JsonConvert.SerializeObject(bucher));
                    Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplare));

                    Console.WriteLine("Eintrag {0} mit dem Titel \"{1}\" und die dazugehörigen Exemplare wurden entfernt.", nummer, entferntesBuch);
                    */
                    //break;
                case 2:
                    if (File.Exists(pfadExemplareBucher))
                    {
                        Options.List((int)ProductSelection.Exemplare);

                        Console.Write("\nVon welchem Buch möchten Sie Exemplare entfernen (Nummer): ");
                        var entfernteExemplare = Convert.ToInt32(Console.ReadLine());
                        Console.Write("\n{0} Exemplare sind momentan vermerkt. Wie viel sollen entfernt werden: ", exemplareBucher[entfernteExemplare].Exemplare);
                        var anzahlEntfernteExemplare = Convert.ToInt32(Console.ReadLine());

                        while (anzahlEntfernteExemplare < 0 || anzahlEntfernteExemplare > exemplareBucher.Count)
                        {
                            Console.WriteLine("So viele Exemplare können nicht entfernt werden.");
                            Console.Write("Wie viel sollen entfernt werden: ");
                            anzahlEntfernteExemplare = Convert.ToInt32(Console.ReadLine());
                        }

                        exemplareBucher[anzahlEntfernteExemplare].Exemplare = exemplareBucher[entfernteExemplare].Exemplare - anzahlEntfernteExemplare;
                        
                        Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplareBucher));

                        Console.WriteLine("{0} Exemplar(e) wurde(n) erfolgreich entfernt.", anzahlEntfernteExemplare);
                    }
                    else
                    {
                        Console.WriteLine("\nKeine Exemplare vorhanden.");
                    }

                    break;
                case 3:
                    Options.List((int)ProductSelection.Leihvorgange);

                    Console.Write("Welcher Leihvorgang soll gelöscht werden (Nummer): ");
                    var zuLöschenderLeihvorgang = Convert.ToInt32(Console.ReadLine());

                    while (zuLöschenderLeihvorgang < 0 || zuLöschenderLeihvorgang > leihvorgange.Count)
                    {
                        Console.Write("Bitte gib eine vorhandene Nummer ein: ");
                        zuLöschenderLeihvorgang = Convert.ToInt32(Console.ReadLine());
                    }

                    var geloschterLeihvorgangKunde = leihvorgange.Find(x => x.Nummer == zuLöschenderLeihvorgang).Kunde;
                    var geloschterLeihvorgangTitle = leihvorgange.Find(x => x.Nummer == zuLöschenderLeihvorgang).Title;

                    var neuAnzahlverliehen = exemplareBucher.Find(x => x.BuchId == leihvorgange[zuLöschenderLeihvorgang - 1].BuchId).AnzahlVerliehen - 1;
                    exemplareBucher.Find(x => x.BuchId == leihvorgange[zuLöschenderLeihvorgang - 1].BuchId).AnzahlVerliehen = neuAnzahlverliehen;

                    leihvorgange.RemoveAll(p => p.Nummer == zuLöschenderLeihvorgang);

                    var l = 0;
                    foreach (var leihvorgang in leihvorgange)
                    {
                        l++;
                        leihvorgang.Nummer = l;
                    }

                    Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                    Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplareBucher));

                    Console.WriteLine("\nLeihvorgang von \"{0}\" zum Buch {1} wurde entfernt.", geloschterLeihvorgangKunde, geloschterLeihvorgangTitle);

                    break;
            }
        }

        public static void Edit(int auswahl)
        {
            const string pfadBucher = @"data/books.json";
            const string pfadExemplareBucher = @"data/exemplare_books.json";
            const string pfadExemplareMagazine = @"data/exemplare_books.json";
            const string pfadLeihvorgange = @"data/leihvorgange.json";
            const string pfadMagazine = @"data/magazine.json";
            var bucher = JsonConvert.DeserializeObject<List<Buch>>(Product.Load(pfadBucher));
            var magazine = JsonConvert.DeserializeObject<List<Magazin>>(Product.Load(pfadMagazine));
            var exemplareBucher = JsonConvert.DeserializeObject<List<ExemplarBuch>>(Product.Load(pfadExemplareBucher, pfadBucher));
            var leihvorgange = new List<Leihvorgang>();

            switch (auswahl)
            {
                case 1:
                    List((int)ProductSelection.Bucher);
                    string mehrBearbeiten;
                    int editAuswahl;

                    Console.Write("Welches Buch möchten Sie bearbeiten (Nummer): ");
                    var buchBearbeiten = Convert.ToInt32(Console.ReadLine());

                    while (buchBearbeiten < 0 || buchBearbeiten > bucher.Count)
                    {
                        Console.WriteLine("Das Buch gibts es nicht.");
                        Console.Write("Buchnummer: ");
                        buchBearbeiten = Convert.ToInt32(Console.ReadLine());
                    }

                    //Process.Start(System.Environment.GetEnvironmentVariable("COMSPEC"), "/C " + "start " + "https://www.google.com/search?q=lesen+lernen#:~:text=aus%20dem%20Web-,Lesen%20lernen%3A%2012%20Tipps%20f%C3%BCr%20Eltern%20und%20Kinder%20(%2B%20%C3%9Cbungen),-Leselust%20wecken.");

                    var table = new ConsoleTable("Nummer", "Titel", "Author", "Seiten", "Land", "Sprache", "Erscheinungsjahr");

                    table.AddRow(bucher[buchBearbeiten - 1].Nummer, bucher[buchBearbeiten - 1].Title, bucher[buchBearbeiten - 1].Author, bucher[buchBearbeiten - 1].Pages, bucher[buchBearbeiten - 1].Country, bucher[buchBearbeiten - 1].Language, bucher[buchBearbeiten - 1].Year);
                    table.Write();


                    do
                    {
                        Console.WriteLine("\nWas möchten Sie bearbeiten?");
                        Console.WriteLine("Titel(1) \nAuthor(2) \nSeiten(3) \nLand(4) \nSprache(5) \nErscheinungsjahr(6)");
                        Console.Write("Nummer: ");
                        editAuswahl = Convert.ToInt32(Console.ReadLine());

                        switch (editAuswahl)
                        {
                            case 1:
                                Console.Write("Neuer/überarbeiteter Titel: ");
                                var title = Console.ReadLine();
                                bucher[buchBearbeiten - 1].Title = title;
                                Console.WriteLine("Titel erfolgreich geändert in {0}", title);
                                break;
                            case 2:
                                Console.Write("Neuer/überarbeiteter Autor: ");
                                var author = Console.ReadLine();
                                bucher[buchBearbeiten - 1].Author = author;
                                Console.WriteLine("Autor erfolgreich geändert in {0}", author);
                                break;
                            case 3:
                                Console.Write("Überarbeitete Seiten: ");
                                var pages = Convert.ToInt32(Console.ReadLine());
                                bucher[buchBearbeiten - 1].Pages = pages;
                                Console.WriteLine("Seiten erfolgreich geändert in {0}", pages);
                                break;
                            case 4:
                                Console.Write("Neues/überarbeitetes Land: ");
                                var country = Console.ReadLine();
                                bucher[buchBearbeiten - 1].Country = country;
                                Console.WriteLine("Land erfolgreich geändert in {0}", country);
                                break;
                            case 5:
                                Console.Write("Neue/überarbeitete Sprache: ");
                                var language = Console.ReadLine();
                                bucher[buchBearbeiten - 1].Language = language;
                                Console.WriteLine("Sprache erfolgreich geändert in {0}", language);
                                break;
                            case 6:
                                Console.Write("Neues/überarbeitetes Erscheinungsjahr: ");
                                var year = Convert.ToInt32(Console.ReadLine());
                                bucher[buchBearbeiten - 1].Year = year;
                                Console.WriteLine("Land erfolgreich geändert in {0}", year);
                                break;
                        }
                        Product.Save(pfadBucher, JsonConvert.SerializeObject(bucher));

                        Console.WriteLine("Mehr an diesem Buch bearbeiten? (j/n)");
                        mehrBearbeiten = Console.ReadLine();
                    } while (mehrBearbeiten == "j");
                    break;
                case 2:
                    List((int)ProductSelection.Exemplare);
                    Console.WriteLine("Welche Exemplare möchten Sie bearbeiten (Nummer): ");
                    var exemplarBearbeiten = Convert.ToInt32(Console.ReadLine());

                    while (exemplarBearbeiten < 0 || exemplarBearbeiten > exemplareBucher.Count)
                    {
                        Console.WriteLine("Dieses Buch gibt es nicht.");
                        Console.Write("Nummer: ");
                        exemplarBearbeiten = Convert.ToInt32(Console.ReadLine());
                    }

                    table = new ConsoleTable("Nummer", "Titel", "Exemplare", "verliehen");
                    table.AddRow(exemplareBucher[exemplarBearbeiten - 1].Nummer, exemplareBucher[exemplarBearbeiten - 1].Title, exemplareBucher[exemplarBearbeiten - 1].Exemplare, exemplareBucher[exemplarBearbeiten - 1].AnzahlVerliehen);
                    table.Write();

                    Console.WriteLine("\nWas möchten Sie editieren?");
                    Console.WriteLine("\nExemplare(1)");
                    Console.Write("Nummer: ");
                    editAuswahl = Convert.ToInt32(Console.ReadLine());

                    switch (editAuswahl)
                    {
                        case 1:
                            Console.Write("Neuer Anzahl an Exemplaren: ");
                            var neueAnzahlExemplare = Convert.ToInt32(Console.ReadLine());
                            exemplareBucher[exemplarBearbeiten].Exemplare = neueAnzahlExemplare;
                            Console.WriteLine("Exemplare erfolgreich geändert in {0}", neueAnzahlExemplare);
                            break;
                    }
                    Product.Save(pfadExemplareBucher, JsonConvert.SerializeObject(exemplareBucher));
                    break;
                case 3:
                    List((int)ProductSelection.Leihvorgange);
                    Console.Write("Welchen Leihvorgang möchten Sie bearbeiten (Nummer): ");
                    var leihvorgangBearbeiten = Convert.ToInt32(Console.ReadLine());

                    table = new ConsoleTable("Nummer", "Titel", "verliehen am", "Leihdauer", "geliehen von", "verfügbar ab");
                    table.AddRow(leihvorgange[leihvorgangBearbeiten - 1].Nummer,
                        leihvorgange[leihvorgangBearbeiten - 1].Title,
                        leihvorgange[leihvorgangBearbeiten - 1].VerliehenAm,
                        leihvorgange[leihvorgangBearbeiten - 1].Leihdauer,
                        leihvorgange[leihvorgangBearbeiten - 1].Kunde,
                        leihvorgange[leihvorgangBearbeiten - 1].VerfugbarAb);
                    table.Write();

                    Console.WriteLine("Was möchten Sie bearbeiten?");
                    Console.WriteLine("\ngeliehen von(1) \nLeihdauer(2)");
                    Console.Write("Nummer: ");
                    editAuswahl = Convert.ToInt32(Console.ReadLine());

                    switch (editAuswahl)
                    {
                        case 1:
                            Console.Write("Neuer Kunde: ");
                            var kunde = Console.ReadLine();
                            leihvorgange[leihvorgangBearbeiten-1].Kunde = kunde;
                            Console.WriteLine("Kunde/verliehen an erfolgreich geändert in {0}", kunde);
                            break;
                        case 2:
                            Console.Write("Neue Leihdauer: ");
                            var leihdauer = Convert.ToInt32(Console.ReadLine());
                            leihvorgange[leihvorgangBearbeiten - 1].Leihdauer = leihdauer;

                            var verfugbarAb = Convert.ToDateTime(leihvorgange[leihvorgangBearbeiten - 1].VerliehenAm)
                                .AddDays(leihdauer).ToString("dd/MM/yyyy");
                            leihvorgange[leihvorgangBearbeiten - 1].VerfugbarAb = verfugbarAb;
                            break;
                    }
                    Product.Save(pfadLeihvorgange, JsonConvert.SerializeObject(leihvorgange));
                    break;
                case 4:
                    List((int)ProductSelection.Magazine);

                    Console.Write("Welches Magazin möchten Sie bearbeiten (Nummer): ");
                    var magazinBearbeiten = Convert.ToInt32(Console.ReadLine());

                    while (magazinBearbeiten < 0 || magazinBearbeiten> magazine.Count)
                    {
                        Console.WriteLine("Das Buch gibts es nicht.");
                        Console.Write("Buchnummer: ");
                        magazinBearbeiten = Convert.ToInt32(Console.ReadLine());
                    }

                    table = new ConsoleTable("Nummer", "Titel", "Gruppe", "Sachgruppe", "Verlag");

                    table.AddRow(magazine[magazinBearbeiten - 1].Nummer, magazine[magazinBearbeiten - 1].Title, magazine[magazinBearbeiten - 1].Gruppe, magazine[magazinBearbeiten - 1].Sachgruppe, magazine[magazinBearbeiten - 1].Verlag);
                    table.Write();

                    do
                    {
                        Console.WriteLine("\nWas möchten Sie bearbeiten?");
                        Console.WriteLine("Titel(1) \nGurppe(2) \nSachgruppe(3) \nVerlag(4)");
                        Console.Write("Nummer: ");
                        editAuswahl = Convert.ToInt32(Console.ReadLine());

                        switch (editAuswahl)
                        {
                            case 1:
                                Console.Write("Neuer/überarbeiteter Titel: ");
                                var title = Console.ReadLine();
                                magazine[magazinBearbeiten - 1].Title = title;
                                Console.WriteLine("\nTitel erfolgreich geändert in {0}\n", title);
                                break;
                            case 2:
                                Console.Write("Neuee/überarbeitete Gruppe: ");
                                var gruppe = Console.ReadLine();
                                magazine[magazinBearbeiten - 1].Gruppe = gruppe;
                                Console.WriteLine("\nGruppe erfolgreich geändert in {0}\n", gruppe);
                                break;
                            case 3:
                                Console.Write("Überarbeitete Sachgruppe: ");
                                var sachgruppe = Console.ReadLine();
                                magazine[magazinBearbeiten - 1].Sachgruppe = sachgruppe;
                                Console.WriteLine("\nSachgruppe erfolgreich geändert in {0}\n", sachgruppe);
                                break;
                            case 4:
                                Console.Write("Neuer/Überarbeiteter Verlag: ");
                                var verlag = Console.ReadLine();
                                magazine[magazinBearbeiten - 1].Verlag = verlag;
                                Console.WriteLine("\nVerlag erfolgreich geändert in {0}\n", verlag);
                                break;
                        }
                        Product.Save(pfadMagazine, JsonConvert.SerializeObject(magazine));

                        Console.WriteLine("Mehr an diesem Magazin bearbeiten? (j/n)\n");
                        mehrBearbeiten = Console.ReadLine();
                    } while (mehrBearbeiten == "j");
                    break;
            }
        }
    }
}
