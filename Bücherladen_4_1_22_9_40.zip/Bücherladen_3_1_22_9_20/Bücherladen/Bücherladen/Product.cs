﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Bücherladen
{
    public abstract class Product
    {
        public int Nummer;
        public string Art;
        public string Title;
        public Guid Id;

        protected Product(int nummer, string art, string title, Guid id)
        {
            Nummer = nummer;
            Art = art;
            Title = title;
            Id = id;
        }

        public static string Load(string pfad)
        {
            var jsonString = "";

            if (File.Exists(pfad))
            {
                var rLeihvorgange = new StreamReader(pfad);
                jsonString = rLeihvorgange.ReadToEnd();
                
                rLeihvorgange.Close();
            }
            else
                return null;

            return jsonString;
        }

        //für exemplare only:
        public static string Load(string pfad, string pfadBucher)
        {
            var jsonString = "";

            if (!File.Exists(pfad))
            {
                var jsonListBucher = new List<ExemplarBuch>();
                var bucherList = JsonConvert.DeserializeObject<List<Buch>>(Load(pfadBucher));

                jsonListBucher.AddRange(bucherList.Select(buch => new ExemplarBuch(buch.Nummer, buch.Id, buch.Title, 2, 0)));
                
                var json = JsonConvert.SerializeObject(jsonListBucher.ToArray());

                Save(pfad, json);
            }

            jsonString = Load(pfad);

            return jsonString;
        }

        public static string Load(string pfad, string pfadMagazine, bool magazineTrue)
        {
            var jsonString = "";

            if (!File.Exists(pfad))
            {
                var jsonListMagazine = new List<ExemplarMagazin>();
                var magazineList = JsonConvert.DeserializeObject<List<Buch>>(Load(pfadMagazine));

                jsonListMagazine.AddRange(magazineList.Select(magazin => new ExemplarMagazin(magazin.Nummer, magazin.Id, magazin.Title, 2, 0)));

                var json = JsonConvert.SerializeObject(jsonListMagazine.ToArray());

                Save(pfad, json);
            }

            jsonString = Load(pfad);

            return jsonString;
        }

        public static void CorrectWrongId(List<Buch> list, string pfad)
        {
            foreach(var product in list)
            {
                if(product.Id.ToString() == "00000000-0000-0000-0000-000000000000")
                {
                    product.Id = Guid.NewGuid();
                }
            }
            Save(pfad, JsonConvert.SerializeObject(list));
        }

        public static void CorrectWrongId(List<Magazin> list, string pfad)
        {
            foreach (var product in list)
            {
                if (product.Id.ToString() == "00000000-0000-0000-0000-000000000000")
                {
                    product.Id = Guid.NewGuid();
                }
            }
            Save(pfad, JsonConvert.SerializeObject(list));
        }

        public static void Save(string pfad, string jsonString)
        {
            File.WriteAllText(pfad, jsonString);
        }
    }
}
