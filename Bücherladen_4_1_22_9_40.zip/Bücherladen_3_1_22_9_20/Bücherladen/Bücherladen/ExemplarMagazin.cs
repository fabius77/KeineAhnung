﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bücherladen
{
    class ExemplarMagazin
    {
        public int Nummer;
        public string Title;
        public Guid MagazinId;
        public int Exemplare;
        public int AnzahlVerliehen;
        public string Art;
        public int Downloads;

        public ExemplarMagazin(int nummer, Guid magazinId, string title, int exemplare, int downloads)
        {
            Nummer = nummer;
            MagazinId = magazinId;
            Title = title;
            Exemplare = exemplare;
            Art = "MAGAZIN";
            Downloads = downloads;
        }
    }
}
